package spms.vo;

public class Search {
	private String search_value;

	public String getSearch_value() {
		return search_value;
	}

	public void setSearch_value(String search_value) {
		this.search_value = search_value;
	}
	
	
}
