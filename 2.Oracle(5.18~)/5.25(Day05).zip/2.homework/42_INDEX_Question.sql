1) 어제 만든 PAYMENT 테이블의 PDATE 컬럼에 INDEX를 추가하세요.


2) 어제 만든 PAYMENT_DETAIL 테이블의 AMOUNT, PRICE 컬럼에 INDEX를 추가하세요.